# Roblox Mass Report
I couldn't find a roblox mass report so I decided to make one myself and share it on Github.  
This tool just spams the roblox report api with random user agents and proxies, but most doesnt proxies doesnt work  
This could be ran on [Replit](https://replit.com/).  
**It's for educational Purposes only**  

## Tutorial

1. Install Python and Select Add to Path  
2. Run `setup.bat`  
3. Add Roblox Cookies to `cookies.txt`, each seperated by a line break (by pressing enter) (recommend alt cookies since it's bannable)  
4. Add report descriptions in `main.py` in reason descriptions, (optional, but recommend)  
5. Run `main.py` and type the victim's user and how much reports to send and which type of report to send
## Preview
and stop stealing credits u fucking skids  
DM `Dreamer#5114` on discord for help

![image](https://user-images.githubusercontent.com/104280094/183817570-6ddaa4be-0a11-46da-bf2d-3b959ba95d49.png)
